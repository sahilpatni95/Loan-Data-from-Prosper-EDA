# Loan Data from Prosper Dateset

## This data set contains 113,937 loans with 81 variables on each loan, including loan amount, borrower rate (or interest rate), current loan status, borrower income, and many others.

## Dataset

> ### selecting features of interest

> - LoanOriginalAmount',
> - 'LoanStatus',
> - 'BorrowerRate',
> - 'Term',
> - 'ListingCategory (numeric)',
> - 'BorrowerAPR',
> - 'StatedMonthlyIncome',
> - 'IncomeRange',
> - 'LoanOriginationQuarter',
> - 'ProsperScore',
> - 'TotalInquiries',
> - 'EmploymentStatus',
> - 'ProsperRating (Alpha)'

###### There are 113,937 records and 81 columns




